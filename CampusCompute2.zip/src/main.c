#include "campus.h"

void show_help(void)
{
    printf("\n========== CAMPUSCOMPUTE ==========\n");
    printf("CPU Scheduling and OS Concepts Simulator\n");
    printf("====================================\n\n");

    printf("Available Commands:\n\n");

    printf("  ./campuscompute help\n");
    printf("      Display available commands\n\n");

    printf("  ./campuscompute schedule fcfs\n");
    printf("      First Come First Serve scheduling\n\n");

    printf("  ./campuscompute schedule rr\n");
    printf("      Round Robin scheduling\n\n");

    printf("  ./campuscompute schedule priority\n");
    printf("      Non-preemptive Priority scheduling\n\n");

    printf("  ./campuscompute compare\n");
    printf("      Compare all scheduling algorithms\n\n");

    printf("  ./campuscompute logger\n");
    printf("      Run producer-consumer logger\n\n");

    printf("  ./campuscompute ipc\n");
    printf("      Demonstrate shared memory and semaphores\n\n");

    printf("  ./campuscompute banker safe\n");
    printf("      Test a safe resource allocation\n\n");

    printf("  ./campuscompute banker unsafe\n");
    printf("      Test an unsafe resource allocation\n\n");
    
    printf("  ./campuscompute banker custom\n");
    printf("      Enter custom resource allocation data\n\n");

    printf("  ./campuscompute worker normal\n");
    printf("      Demonstrate normal worker completion\n\n");

    printf("  ./campuscompute worker fail\n");
    printf("      Demonstrate simulated worker failure\n\n");

    printf("  ./campuscompute limit\n");
    printf("      Demonstrate process resource limits\n\n");

    printf("  ./campuscompute demo\n");
    printf("      Run integrated demonstration\n\n");

    printf("  ./campuscompute cleanup\n");
    printf("      Clean up program-created IPC resources\n\n");
}

int main(int argc, char *argv[])
{
    if (argc < 2 || strcmp(argv[1], "help") == 0)
    {
        show_help();
        return 0;
    }

    if (strcmp(argv[1], "schedule") == 0)
        return run_scheduler(argc, argv);

    else if (strcmp(argv[1], "compare") == 0)
        return run_scheduler(argc, argv);

    else if (strcmp(argv[1], "logger") == 0)
        return run_logger();

    else if (strcmp(argv[1], "ipc") == 0)
        return run_ipc();

    else if (strcmp(argv[1], "banker") == 0)
        return run_banker(argc, argv);

    else if (strcmp(argv[1], "worker") == 0)
        return run_worker(argc, argv);

    else if (strcmp(argv[1], "limit") == 0)
        return run_limits();

    else if (strcmp(argv[1], "demo") == 0)
        return run_demo();

    else if (strcmp(argv[1], "cleanup") == 0)
        return run_cleanup();

    else
    {
        fprintf(stderr, "Error: Unknown command '%s'.\n", argv[1]);
        fprintf(stderr, "Use './campuscompute help' to see available commands.\n");
        return 1;
    }
}
int run_demo(void)
{
    char *banker_safe_args[] = {"campuscompute", "banker", "safe", NULL};
    char *banker_unsafe_args[] = {"campuscompute", "banker", "unsafe", NULL};
    char *worker_normal_args[] = {"campuscompute", "worker", "normal", NULL};
    char *worker_fail_args[] = {"campuscompute", "worker", "fail", NULL};

    int sched, logger, ipc, bank_safe, bank_unsafe;
    int w_normal, w_fail, limits, cleanup;

    printf("\n========== CAMPUSCOMPUTE INTEGRATED DEMO ==========\n");

    printf("\n--- CPU SCHEDULING (fixed sample jobs) ---\n");
    sched = run_scheduler_sample();

    printf("\n--- PRODUCER-CONSUMER LOGGER ---\n");
    logger = run_logger();

    printf("\n--- SHARED MEMORY AND SEMAPHORE ---\n");
    ipc = run_ipc();

    printf("\n--- BANKER'S ALGORITHM ---\n");
    bank_safe = run_banker(3, banker_safe_args);
    bank_unsafe = run_banker(3, banker_unsafe_args);

    printf("\n--- WORKER PROCESSES ---\n");
    w_normal = run_worker(3, worker_normal_args);
    w_fail = run_worker(3, worker_fail_args);

    printf("\n--- RESOURCE LIMITS ---\n");
    limits = run_limits();

    cleanup = run_cleanup();

    printf("\n========== INTEGRATED DEMO SUMMARY ==========\n");
    printf("%-34s %s\n", "CPU scheduling comparison", sched == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Producer-consumer logger", logger == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Shared memory + semaphore IPC", ipc == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Banker's safe state", bank_safe == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Banker's unsafe state", bank_unsafe == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Worker normal completion", w_normal == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Worker simulated failure detected", w_fail == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "Resource limit (RLIMIT_CPU)", limits == 0 ? "OK" : "FAILED");
    printf("%-34s %s\n", "IPC cleanup", cleanup == 0 ? "OK" : "FAILED");
    printf("Log file: %s\n", LOG_FILE);
    printf("========== INTEGRATED DEMO COMPLETED ==========\n");

    return (sched | logger | ipc | bank_safe | bank_unsafe |
            w_normal | w_fail | limits | cleanup) ? 1 : 0;
}

int run_cleanup(void)
{
    printf("\n========== CAMPUSCOMPUTE CLEANUP ==========\n");

    int shm_result = shm_unlink("/campuscompute_shm");
    int shm_error = errno;

    int sem_result = sem_unlink("/campuscompute_sem");
    int sem_error = errno;
    
    int done_result = sem_unlink("/campuscompute_done");
    int done_error = errno;
    
    if (shm_result == 0)
        printf("Shared memory resource removed.\n");
    else if (shm_error == ENOENT)
        printf("No shared memory resource to remove.\n");
    else
        printf("Shared memory cleanup failed: %s\n", strerror(shm_error));

    if (sem_result == 0)
        printf("Named semaphore removed.\n");
    else if (sem_error == ENOENT)
        printf("No named semaphore to remove.\n");
    else
        printf("Semaphore cleanup failed: %s\n", strerror(sem_error));
    
    if (done_result == 0)
        printf("Completion semaphore removed.\n");
    else if (done_error == ENOENT)
        printf("No completion semaphore to remove.\n");
    else
        printf("Completion semaphore cleanup failed: %s\n",
        strerror(done_error)); 
    printf("Cleanup operation completed.\n");
    return 0;
}
