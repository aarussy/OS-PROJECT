#include "campus.h"

int run_worker(int argc, char *argv[])
{
    if (argc < 3)
    {
        printf("Usage: ./campuscompute worker <normal|fail>\n");
        return 1;
    }

    int simulate_failure = 0;

    if (strcmp(argv[2], "normal") == 0)
    {
        simulate_failure = 0;
    }
    else if (strcmp(argv[2], "fail") == 0)
    {
        simulate_failure = 1;
    }
    else
    {
        printf("Invalid option. Use normal or fail.\n");
        return 1;
    }

    printf("\n========== WORKER PROCESS MANAGEMENT ==========\n");

    printf("[Parent] Creating worker process...\n");

    fflush(stdout);   /* avoid duplicated buffered output in the child */
    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return 1;
    }

    if (pid == 0)
    {
        printf("\n[Child] Worker started.\n");
        printf("[Child] Process ID: %d\n", getpid());

        if (simulate_failure)
        {
            printf("[Child] [SIMULATED FAILURE] Exiting with code 42 on purpose (not a real OS failure).\n");
            fflush(stdout);

            _exit(42);
        }

        printf("[Child] Processing assigned job...\n");
        sleep(2);

        printf("[Child] Job completed successfully.\n");
        fflush(stdout);

        _exit(0);
    }

    printf("[Parent] Worker created successfully.\n");
    printf("[Parent] Child PID: %d\n", pid);

    int status;

    if (waitpid(pid, &status, 0) == -1)
    {
        perror("waitpid");
        return 1;
    }

    printf("\n[Parent] Worker status received.\n");

    if (WIFEXITED(status))
    {
        int exit_code = WEXITSTATUS(status);

        if (exit_code == 0)
        {
            printf("[Parent] Worker completed normally.\n");
            printf("[Parent] Exit status: %d\n", exit_code);
        }
        else
        {
            printf("[Parent] Worker failed with non-zero exit status.\n");
            printf("[Parent] Exit status: %d\n", exit_code);
            printf("[Parent] Detected the SIMULATED worker failure (intentional exit code 42).\n");
        }
    }
    else if (WIFSIGNALED(status))
    {
        printf("[Parent] Worker terminated by signal: %d\n",
               WTERMSIG(status));
    }
    else
    {
        printf("[Parent] Worker ended with an unexpected status.\n");
    }

    return 0;
}
