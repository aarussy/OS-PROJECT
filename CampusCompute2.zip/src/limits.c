#include "campus.h"

static void cpu_limit_handler(int signal_number)
{
    const char message[] =
        "\n[Child] CPU time limit exceeded! SIGXCPU received.\n";

    (void)signal_number;
    write(STDOUT_FILENO, message, sizeof(message) - 1);

    _exit(24);
}

int run_limits(void)
{
    printf("\n========== RESOURCE LIMIT DEMONSTRATION ==========\n");
    printf("[Parent] Creating child process...\n");
    fflush(stdout);

    pid_t pid = fork();

    if (pid < 0)
    {
        perror("fork");
        return 1;
    }

    if (pid == 0)
    {
        struct rlimit cpu_limit;

        cpu_limit.rlim_cur = 1;
        cpu_limit.rlim_max = 2;

        if (setrlimit(RLIMIT_CPU, &cpu_limit) == -1)
        {
            perror("setrlimit");
            _exit(1);
        }

        if (signal(SIGXCPU, cpu_limit_handler) == SIG_ERR)
        {
            perror("signal");
            _exit(1);
        }

        printf("[Child] CPU soft limit: 1 second\n");
        printf("[Child] CPU hard limit: 2 seconds\n");
        printf("[Child] Starting CPU-intensive task...\n");
        fflush(stdout);

        volatile unsigned long counter = 0;

        while (1)
        {
            counter++;
        }
    }

    int status;

    if (waitpid(pid, &status, 0) == -1)
    {
        perror("waitpid");
        return 1;
    }

    printf("\n[Parent] Child process terminated.\n");

    if (WIFEXITED(status))
    {
        printf("[Parent] Child exit status: %d\n",
               WEXITSTATUS(status));

        if (WEXITSTATUS(status) == 24)
            printf("[Parent] CPU resource limit was successfully enforced.\n");
    }
    else if (WIFSIGNALED(status))
    {
        printf("[Parent] Child terminated by signal: %d\n",
               WTERMSIG(status));
    }

    printf("[Parent] Parent process remains unaffected.\n");

    return 0;
}
