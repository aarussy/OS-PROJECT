#include "campus.h"
#include <limits.h>

#define PROCESS_COUNT 5
#define RESOURCE_COUNT 3

static int read_value(const char *prompt, int min, int max)
{
    char input[128];
    char *end;
    long value;

    while (1)
    {
        printf("%s", prompt);

        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("\nInput error.\n");
            exit(1);
        }

        errno = 0;
        value = strtol(input, &end, 10);

        while (*end == ' ' || *end == '\t' ||
               *end == '\n' || *end == '\r')
            end++;

        if (errno == 0 && end != input && *end == '\0' &&
            value >= min && value <= max)
            return (int)value;

        printf("Invalid input. Enter a value between %d and %d.\n",
               min, max);
    }
}

static void calculate_need(int allocation[PROCESS_COUNT][RESOURCE_COUNT],
                           int maximum[PROCESS_COUNT][RESOURCE_COUNT],
                           int need[PROCESS_COUNT][RESOURCE_COUNT],
                           int processes, int resources)
{
    for (int i = 0; i < processes; i++)
    {
        for (int j = 0; j < resources; j++)
            need[i][j] = maximum[i][j] - allocation[i][j];
    }
}

static int safety_algorithm(int available[RESOURCE_COUNT],
                            int allocation[PROCESS_COUNT][RESOURCE_COUNT],
                            int maximum[PROCESS_COUNT][RESOURCE_COUNT],
                            int processes, int resources)
{
    int need[PROCESS_COUNT][RESOURCE_COUNT] = {0};
    int work[RESOURCE_COUNT];
    int finish[PROCESS_COUNT] = {0};
    int safe_sequence[PROCESS_COUNT];
    int count = 0;

    calculate_need(allocation, maximum, need,
                   processes, resources);

    for (int i = 0; i < resources; i++)
        work[i] = available[i];

    printf("\nNeed Matrix:\n");

    for (int i = 0; i < processes; i++)
    {
        printf("P%d: ", i);

        for (int j = 0; j < resources; j++)
            printf("%d ", need[i][j]);

        printf("\n");
    }

    while (count < processes)
    {
        int found = 0;

        for (int i = 0; i < processes; i++)
        {
            if (finish[i])
                continue;

            int possible = 1;

            for (int j = 0; j < resources; j++)
            {
                if (need[i][j] > work[j])
                {
                    possible = 0;
                    break;
                }
            }

            if (possible)
            {
                for (int j = 0; j < resources; j++)
                    work[j] += allocation[i][j];

                safe_sequence[count++] = i;
                finish[i] = 1;
                found = 1;
            }
        }

        if (!found)
            break;
    }

    if (count == processes)
    {
        printf("\nSystem is in a SAFE state.\n");
        printf("Safe Sequence: ");

        for (int i = 0; i < processes; i++)
        {
            printf("P%d", safe_sequence[i]);

            if (i != processes - 1)
                printf(" -> ");
        }

        printf("\n");
        return 1;
    }

    printf("\nSystem is in an UNSAFE state.\n");
    printf("No safe sequence exists.\n");

    return 0;
}

static void display_matrices(int available[RESOURCE_COUNT],
                             int allocation[PROCESS_COUNT][RESOURCE_COUNT],
                             int maximum[PROCESS_COUNT][RESOURCE_COUNT],
                             int processes, int resources)
{
    printf("\nAvailable Resources: ");

    for (int j = 0; j < resources; j++)
        printf("%d ", available[j]);

    printf("\n\nAllocation Matrix:\n");

    for (int i = 0; i < processes; i++)
    {
        printf("P%d: ", i);

        for (int j = 0; j < resources; j++)
            printf("%d ", allocation[i][j]);

        printf("\n");
    }

    printf("\nMaximum Matrix:\n");

    for (int i = 0; i < processes; i++)
    {
        printf("P%d: ", i);

        for (int j = 0; j < resources; j++)
            printf("%d ", maximum[i][j]);

        printf("\n");
    }
}

int run_banker(int argc, char *argv[])
{
    int available[RESOURCE_COUNT] = {0};
    int allocation[PROCESS_COUNT][RESOURCE_COUNT] = {{0}};
    int maximum[PROCESS_COUNT][RESOURCE_COUNT] = {{0}};

    int processes = PROCESS_COUNT;
    int resources = RESOURCE_COUNT;

    if (argc < 3)
    {
        printf("Usage: ./campuscompute banker <safe|unsafe|custom>\n");
        return 1;
    }

    if (strcmp(argv[2], "safe") == 0)
    {
        int a[] = {3, 3, 2};

        int alloc[PROCESS_COUNT][RESOURCE_COUNT] =
        {
            {0, 1, 0},
            {2, 0, 0},
            {3, 0, 2},
            {2, 1, 1},
            {0, 0, 2}
        };

        int max[PROCESS_COUNT][RESOURCE_COUNT] =
        {
            {7, 5, 3},
            {3, 2, 2},
            {9, 0, 2},
            {2, 2, 2},
            {4, 3, 3}
        };

        memcpy(available, a, sizeof(a));
        memcpy(allocation, alloc, sizeof(alloc));
        memcpy(maximum, max, sizeof(max));

        printf("\n========== BANKER'S ALGORITHM ==========\n");
        printf("Testing predefined SAFE state.\n");
    }
    else if (strcmp(argv[2], "unsafe") == 0)
    {
        int a[] = {0, 0, 0};

        int alloc[PROCESS_COUNT][RESOURCE_COUNT] =
        {
            {1, 0, 0},
            {0, 1, 0},
            {0, 0, 1},
            {1, 1, 0},
            {0, 0, 1}
        };

        int max[PROCESS_COUNT][RESOURCE_COUNT] =
        {
            {2, 0, 0},
            {0, 2, 0},
            {0, 0, 2},
            {2, 2, 0},
            {0, 0, 2}
        };

        memcpy(available, a, sizeof(a));
        memcpy(allocation, alloc, sizeof(alloc));
        memcpy(maximum, max, sizeof(max));

        printf("\n========== BANKER'S ALGORITHM ==========\n");
        printf("Testing predefined UNSAFE state.\n");
    }
    else if (strcmp(argv[2], "custom") == 0)
    {
        printf("\n========== CUSTOM BANKER'S INPUT ==========\n");

        processes = read_value("Number of processes (1-5): ",
                               1, PROCESS_COUNT);

        resources = read_value("Number of resource types (1-3): ",
                               1, RESOURCE_COUNT);

        printf("\nEnter Available resources:\n");

        for (int j = 0; j < resources; j++)
        {
            char prompt[80];
            snprintf(prompt, sizeof(prompt),
                     "Available R%d: ", j);

            available[j] = read_value(prompt, 0, INT_MAX);
        }

        printf("\nEnter Allocation Matrix:\n");

        for (int i = 0; i < processes; i++)
        {
            for (int j = 0; j < resources; j++)
            {
                char prompt[80];
                snprintf(prompt, sizeof(prompt),
                         "P%d Allocation R%d: ", i, j);

                allocation[i][j] = read_value(prompt, 0, INT_MAX);
            }
        }

        printf("\nEnter Maximum Matrix:\n");

        for (int i = 0; i < processes; i++)
        {
            for (int j = 0; j < resources; j++)
            {
                char prompt[80];
                snprintf(prompt, sizeof(prompt),
                         "P%d Maximum R%d: ", i, j);

                maximum[i][j] = read_value(prompt,
                                            allocation[i][j], INT_MAX);
            }
        }

        printf("\nCustom resource state entered.\n");
    }
    else
    {
        printf("Invalid option. Use safe, unsafe or custom.\n");
        return 1;
    }

    display_matrices(available, allocation, maximum,
                     processes, resources);

    safety_algorithm(available, allocation, maximum,
                     processes, resources);

    return 0;
}
