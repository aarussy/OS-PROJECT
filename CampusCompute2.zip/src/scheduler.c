#include "campus.h"
#include <limits.h>

typedef struct
{
    int id;
    int arrival;
    int burst;
    int priority;
    int remaining;
    int completion;
    int turnaround;
    int waiting;
    int finished;
} Job;

static Job jobs[MAX_JOBS];
static int job_count;
static float last_avg_tat;
static float last_avg_wt;

/* Read and validate integer input. */
static int read_integer(const char *prompt, int min, int max)
{
    char input[128];
    char *end;
    long value;

    while (1)
    {
        printf("%s", prompt);

        if (fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("\nInput error.\n");
            exit(1);
        }

        errno = 0;
        value = strtol(input, &end, 10);

        while (*end == ' ' || *end == '\t' ||
               *end == '\n' || *end == '\r')
            end++;

        if (errno == 0 && end != input && *end == '\0' &&
            value >= min && value <= max)
        {
            return (int)value;
        }

        printf("Invalid input. Enter a value between %d and %d.\n",
               min, max);
    }
}

/* Get job details from the user. */
static void get_jobs(void)
{
    printf("\n========== JOB INPUT ==========\n");

    job_count = read_integer("Enter number of jobs (1-20): ",
                             1, MAX_JOBS);

    for (int i = 0; i < job_count; i++)
    {
        printf("\nJob J%d\n", i + 1);

        jobs[i].id = i + 1;

        jobs[i].arrival =
            read_integer("Arrival time: ", 0, INT_MAX);

        jobs[i].burst =
            read_integer("CPU burst time: ", 1, INT_MAX);

        jobs[i].priority =
            read_integer("Priority (0 = highest): ", 0, INT_MAX);

        jobs[i].remaining = jobs[i].burst;
        jobs[i].completion = 0;
        jobs[i].turnaround = 0;
        jobs[i].waiting = 0;
        jobs[i].finished = 0;
    }
}

/* Display scheduling results. */
static void display_results(Job j[], int n)
{
    float total_tat = 0;
    float total_wt = 0;

    printf("\nJob\tAT\tBT\tPriority\tCT\tTAT\tWT\n");

    for (int i = 0; i < n; i++)
    {
        printf("J%d\t%d\t%d\t%d\t\t%d\t%d\t%d\n",
               j[i].id,
               j[i].arrival,
               j[i].burst,
               j[i].priority,
               j[i].completion,
               j[i].turnaround,
               j[i].waiting);

        total_tat += j[i].turnaround;
        total_wt += j[i].waiting;
    }

    last_avg_tat = total_tat / n;
    last_avg_wt = total_wt / n;

    printf("\nAverage Turnaround Time: %.2f\n", last_avg_tat);
    printf("Average Waiting Time: %.2f\n", last_avg_wt);
}

/* First Come First Serve scheduling. */
static void fcfs(void)
{
    Job j[MAX_JOBS];
    int time = 0;

    for (int i = 0; i < job_count; i++)
        j[i] = jobs[i];

    /* Sort by arrival time, then Job ID. */
    for (int i = 0; i < job_count - 1; i++)
    {
        for (int k = i + 1; k < job_count; k++)
        {
            if (j[k].arrival < j[i].arrival ||
                (j[k].arrival == j[i].arrival &&
                 j[k].id < j[i].id))
            {
                Job temp = j[i];
                j[i] = j[k];
                j[k] = temp;
            }
        }
    }

    printf("\n========== FCFS SCHEDULING ==========\n");
    printf("Tie-breaking: Earlier arrival, then lower Job ID.\n");
    printf("\nExecution Timeline:\n");

    for (int i = 0; i < job_count; i++)
    {
        if (time < j[i].arrival)
        {
            printf("| IDLE (%d-%d) ", time, j[i].arrival);
            time = j[i].arrival;
        }

        printf("| J%d (%d-%d) ",
               j[i].id, time, time + j[i].burst);

        time += j[i].burst;

        j[i].completion = time;
        j[i].turnaround = time - j[i].arrival;
        j[i].waiting = j[i].turnaround - j[i].burst;
    }

    printf("|\n");
    display_results(j, job_count);
}

/* Round Robin using a FIFO circular ready queue. */
static void round_robin(int quantum)
{
    Job j[MAX_JOBS];
    int queue[MAX_JOBS + 1];
    int admitted[MAX_JOBS] = {0};

    int front = 0;
    int rear = 0;
    int count = 0;
    int time = 0;
    int completed = 0;

    for (int i = 0; i < job_count; i++)
        j[i] = jobs[i];

    printf("\n========== ROUND ROBIN ==========\n");
    printf("Time Quantum: %d units\n", quantum);
    printf("\nExecution Timeline:\n");

    /* Add jobs that have already arrived. */
    for (int i = 0; i < job_count; i++)
    {
        if (j[i].arrival <= time)
        {
            queue[rear] = i;
            rear = (rear + 1) % (MAX_JOBS + 1);
            count++;
            admitted[i] = 1;
        }
    }

    while (completed < job_count)
    {
        /* If no job is ready, advance to the next arrival. */
        if (count == 0)
        {
            int next_arrival = INT_MAX;

            for (int i = 0; i < job_count; i++)
            {
                if (!admitted[i] && j[i].arrival < next_arrival)
                    next_arrival = j[i].arrival;
            }

            printf("| IDLE (%d-%d) ", time, next_arrival);
            time = next_arrival;

            for (int i = 0; i < job_count; i++)
            {
                if (!admitted[i] && j[i].arrival <= time)
                {
                    queue[rear] = i;
                    rear = (rear + 1) % (MAX_JOBS + 1);
                    count++;
                    admitted[i] = 1;
                }
            }
        }

        /* Remove the first job from the ready queue. */
        int current = queue[front];
        front = (front + 1) % (MAX_JOBS + 1);
        count--;

        int start = time;

        int run = (j[current].remaining < quantum) ?
                  j[current].remaining : quantum;

        time += run;
        j[current].remaining -= run;

        printf("| J%d (%d-%d) ", j[current].id, start, time);

        /* Add newly arrived jobs to the back of the queue. */
        for (int i = 0; i < job_count; i++)
        {
            if (!admitted[i] && j[i].arrival <= time)
            {
                queue[rear] = i;
                rear = (rear + 1) % (MAX_JOBS + 1);
                count++;
                admitted[i] = 1;
            }
        }

        if (j[current].remaining == 0)
        {
            j[current].completion = time;
            completed++;
        }
        else
        {
            /* Re-add unfinished job at the back. */
            queue[rear] = current;
            rear = (rear + 1) % (MAX_JOBS + 1);
            count++;
        }
    }

    printf("|\n");

    for (int i = 0; i < job_count; i++)
    {
        j[i].turnaround = j[i].completion - j[i].arrival;
        j[i].waiting = j[i].turnaround - j[i].burst;
    }

    display_results(j, job_count);
}

/* Non-preemptive Priority scheduling. */
static void priority_scheduling(void)
{
    Job j[MAX_JOBS];
    int time = 0;
    int completed = 0;

    for (int i = 0; i < job_count; i++)
        j[i] = jobs[i];

    printf("\n========== PRIORITY SCHEDULING ==========\n");
    printf("Non-preemptive scheduling.\n");
    printf("Lower priority number means higher priority.\n");
    printf("Tie-breaking: Earlier arrival, then lower Job ID.\n");
    printf("\nExecution Timeline:\n");

    while (completed < job_count)
    {
        int selected = -1;

        for (int i = 0; i < job_count; i++)
        {
            if (!j[i].finished && j[i].arrival <= time)
            {
                if (selected == -1 ||
                    j[i].priority < j[selected].priority ||
                    (j[i].priority == j[selected].priority &&
                     (j[i].arrival < j[selected].arrival ||
                      (j[i].arrival == j[selected].arrival &&
                       j[i].id < j[selected].id))))
                {
                    selected = i;
                }
            }
        }

        if (selected == -1)
        {
            int next_arrival = INT_MAX;

            for (int i = 0; i < job_count; i++)
            {
                if (!j[i].finished &&
                    j[i].arrival < next_arrival)
                    next_arrival = j[i].arrival;
            }

            printf("| IDLE (%d-%d) ", time, next_arrival);
            time = next_arrival;
            continue;
        }

        int start = time;

        time += j[selected].burst;

        j[selected].completion = time;
        j[selected].finished = 1;
        completed++;

        printf("| J%d (%d-%d) ",
               j[selected].id, start, time);
    }

    printf("|\n");

    for (int i = 0; i < job_count; i++)
    {
        j[i].turnaround = j[i].completion - j[i].arrival;
        j[i].waiting = j[i].turnaround - j[i].burst;
    }

    display_results(j, job_count);
}

/* Run all three algorithms on the current job set and print a summary. */
static void compare_all(int quantum)
{
    float fcfs_tat, fcfs_wt;
    float rr_tat, rr_wt;
    float priority_tat, priority_wt;

    fcfs();
    fcfs_tat = last_avg_tat;
    fcfs_wt = last_avg_wt;

    round_robin(quantum);
    rr_tat = last_avg_tat;
    rr_wt = last_avg_wt;

    priority_scheduling();
    priority_tat = last_avg_tat;
    priority_wt = last_avg_wt;

    printf("\n========== SCHEDULING COMPARISON SUMMARY ==========\n");
    printf("%-18s %-22s %-20s\n",
           "Algorithm", "Avg Turnaround Time", "Avg Waiting Time");
    printf("%-18s %-22.2f %-20.2f\n", "FCFS", fcfs_tat, fcfs_wt);
    printf("%-18s %-22.2f %-20.2f\n", "Round Robin", rr_tat, rr_wt);
    printf("%-18s %-22.2f %-20.2f\n", "Priority", priority_tat, priority_wt);
}

/* Non-interactive comparison using a fixed, repeatable job set (used by demo). */
int run_scheduler_sample(void)
{
    static const int sample[5][3] = {   /* arrival, burst, priority */
        {0, 5, 2}, {1, 3, 1}, {2, 8, 4}, {3, 6, 3}, {4, 2, 1}
    };
    const int quantum = 2;

    job_count = 5;
    for (int i = 0; i < job_count; i++)
    {
        jobs[i].id = i + 1;
        jobs[i].arrival = sample[i][0];
        jobs[i].burst = sample[i][1];
        jobs[i].priority = sample[i][2];
        jobs[i].remaining = jobs[i].burst;
        jobs[i].completion = jobs[i].turnaround = jobs[i].waiting = 0;
        jobs[i].finished = 0;
    }

    printf("Fixed sample job set (J1-J5), Round Robin quantum = %d\n", quantum);
    compare_all(quantum);
    return 0;
}

/* Command-line entry point. */
int run_scheduler(int argc, char *argv[])
{
    int compare = (strcmp(argv[1], "compare") == 0);

    if (!compare && strcmp(argv[1], "schedule") != 0)
    {
        printf("Usage: ./campuscompute schedule <fcfs|rr|priority>\n");
        return 1;
    }

    if (!compare && argc < 3)
    {
        printf("Usage: ./campuscompute schedule <fcfs|rr|priority>\n");
        return 1;
    }

    if (!compare &&
        strcmp(argv[2], "fcfs") != 0 &&
        strcmp(argv[2], "rr") != 0 &&
        strcmp(argv[2], "priority") != 0 &&
        strcmp(argv[2], "compare") != 0)
    {
        printf("Invalid scheduling algorithm.\n");
        return 1;
    }

    if (!compare && strcmp(argv[2], "compare") == 0)
        compare = 1;

    get_jobs();

    if (compare)
    {
        int quantum = read_integer("\nEnter Round Robin time quantum: ",
                                   1, INT_MAX);
        compare_all(quantum);
    }
    else if (strcmp(argv[2], "fcfs") == 0)
    {
        fcfs();
    }
    else if (strcmp(argv[2], "rr") == 0)
    {
        int quantum = read_integer("Enter Round Robin time quantum: ",
                                   1, INT_MAX);
        round_robin(quantum);
    }
    else
    {
        priority_scheduling();
    }

    return 0;
}
