#include "campus.h"

#define QUEUE_SIZE 5
#define TOTAL_EVENTS 12

typedef struct
{
    char message[150];
} LogEvent;

LogEvent queue[QUEUE_SIZE];

int front = 0;
int rear = 0;
int count = 0;
int producer_done = 0;

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t not_empty = PTHREAD_COND_INITIALIZER;
pthread_cond_t not_full = PTHREAD_COND_INITIALIZER;

FILE *log_file;

void *producer(void *arg)
{
    (void)arg;
    for (int i = 1; i <= TOTAL_EVENTS; i++)
    {
        LogEvent event;

        snprintf(event.message, sizeof(event.message),
                 "Job %d generated an activity event", i);

        pthread_mutex_lock(&mutex);

        while (count == QUEUE_SIZE)
            pthread_cond_wait(&not_full, &mutex);

        queue[rear] = event;
        rear = (rear + 1) % QUEUE_SIZE;
        count++;

        printf("[Producer] Generated: %s\n", event.message);

        pthread_cond_signal(&not_empty);
        pthread_mutex_unlock(&mutex);

        sleep(1);
    }

    pthread_mutex_lock(&mutex);

    producer_done = 1;

    pthread_cond_broadcast(&not_empty);
    pthread_mutex_unlock(&mutex);

    printf("\n[Producer] Finished generating events.\n");

    return NULL;
}

void *consumer(void *arg)
{
    (void)arg;
    while (1)
    {
        pthread_mutex_lock(&mutex);

        while (count == 0 && !producer_done)
            pthread_cond_wait(&not_empty, &mutex);

        if (count == 0 && producer_done)
        {
            pthread_mutex_unlock(&mutex);
            break;
        }

        LogEvent event = queue[front];

        front = (front + 1) % QUEUE_SIZE;
        count--;

        pthread_cond_signal(&not_full);
        pthread_mutex_unlock(&mutex);

        time_t now = time(NULL);
        struct tm timestamp;
        localtime_r(&now, &timestamp);

        char time_string[30];

        strftime(time_string, sizeof(time_string),
                 "%Y-%m-%d %H:%M:%S", &timestamp);

        fprintf(log_file, "[%s] %s\n",
                time_string, event.message);

        fflush(log_file);

        printf("[Consumer] Logged: %s\n", event.message);

        usleep(300000);
    }

    printf("\n[Consumer] Finished processing events.\n");

    return NULL;
}

int run_logger(void)
{
    pthread_t producer_thread;
    pthread_t consumer_thread;

    printf("\n========== CAMPUSCOMPUTE LOGGER ==========\n");

    /* Create the logs directory if it does not exist yet. */
    if (mkdir("logs", 0755) == -1 && errno != EEXIST)
    {
        perror("Unable to create logs directory");
        return 1;
    }

    log_file = fopen(LOG_FILE, "a");

    if (log_file == NULL)
    {
        perror("Unable to open log file");
        return 1;
    }

    producer_done = 0;
    front = 0;
    rear = 0;
    count = 0;

    if (pthread_create(&consumer_thread, NULL, consumer, NULL) != 0)
    {
        perror("Consumer thread creation failed");
        fclose(log_file);
        return 1;
    }

    if (pthread_create(&producer_thread, NULL, producer, NULL) != 0)
    {
        perror("Producer thread creation failed");

        pthread_mutex_lock(&mutex);
        producer_done = 1;
        pthread_cond_broadcast(&not_empty);
        pthread_mutex_unlock(&mutex);

        pthread_join(consumer_thread, NULL);
        fclose(log_file);

        return 1;
    }

    pthread_join(producer_thread, NULL);
    pthread_join(consumer_thread, NULL);

    fclose(log_file);

    printf("\nLogger completed successfully.\n");
    printf("All threads terminated cleanly.\n");
    printf("Log file: %s\n", LOG_FILE);

    return 0;
}
