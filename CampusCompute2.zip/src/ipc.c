#include "campus.h"

#define SHM_NAME "/campuscompute_shm"
#define SEM_NAME "/campuscompute_sem"
#define DONE_NAME "/campuscompute_done"

typedef struct
{
    int job_id;
    char message[100];
    int processed;
} SharedData;

static int wait_semaphore(sem_t *sem)
{
    while (sem_wait(sem) == -1)
    {
        if (errno != EINTR)
            return -1;
    }
    return 0;
}

int run_ipc(void)
{
    printf("\n========== SHARED MEMORY IPC ==========\n");

    int shm_fd = -1;
    SharedData *shared = MAP_FAILED;
    sem_t *parent_sem = SEM_FAILED;
    sem_t *done_sem = SEM_FAILED;
    pid_t pid;
    int status;
    int result = 1;

    shm_fd = shm_open(SHM_NAME, O_CREAT | O_EXCL | O_RDWR, 0600);
    if (shm_fd == -1)
    {
        perror("shm_open");
        goto cleanup;
    }

    if (ftruncate(shm_fd, sizeof(SharedData)) == -1)
    {
        perror("ftruncate");
        goto cleanup;
    }

    shared = mmap(NULL, sizeof(SharedData),
                  PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);

    if (shared == MAP_FAILED)
    {
        perror("mmap");
        goto cleanup;
    }

    parent_sem = sem_open(SEM_NAME, O_CREAT | O_EXCL, 0600, 0);
    if (parent_sem == SEM_FAILED)
    {
        perror("sem_open parent");
        goto cleanup;
    }

    done_sem = sem_open(DONE_NAME, O_CREAT | O_EXCL, 0600, 0);
    if (done_sem == SEM_FAILED)
    {
        perror("sem_open completion");
        goto cleanup;
    }

    shared->job_id = 101;
    strcpy(shared->message, "Job submitted by parent process");
    shared->processed = 0;

    printf("[Parent] Created shared memory.\n");
    printf("[Parent] Submitted Job ID: %d\n", shared->job_id);

    fflush(stdout);   /* avoid duplicated buffered output in the child */
    pid = fork();

    if (pid == -1)
    {
        perror("fork");
        goto cleanup;
    }

    if (pid == 0)
    {
        printf("[Child] Waiting for parent signal...\n");
        fflush(stdout);

        if (wait_semaphore(parent_sem) == -1)
        {
            perror("[Child] sem_wait");
            _exit(1);
        }

        printf("[Child] Received Job ID: %d\n", shared->job_id);
        printf("[Child] Message: %s\n", shared->message);

        shared->processed = 1;

        printf("[Child] Job processed successfully.\n");
        fflush(stdout);

        if (sem_post(done_sem) == -1)
        {
            perror("[Child] sem_post");
            _exit(1);
        }

        munmap(shared, sizeof(SharedData));
        close(shm_fd);
        sem_close(parent_sem);
        sem_close(done_sem);

        _exit(0);
    }

    printf("[Parent] Signalling child process.\n");

    if (sem_post(parent_sem) == -1)
    {
        perror("[Parent] sem_post");
        kill(pid, SIGTERM);
        waitpid(pid, &status, 0);
        goto cleanup;
    }

    printf("[Parent] Waiting for child completion signal.\n");

    if (wait_semaphore(done_sem) == -1)
    {
        perror("[Parent] sem_wait");
        kill(pid, SIGTERM);
        waitpid(pid, &status, 0);
        goto cleanup;
    }

    if (waitpid(pid, &status, 0) == -1)
    {
        perror("waitpid");
        goto cleanup;
    }

    if (WIFEXITED(status) && WEXITSTATUS(status) == 0)
    {
        printf("[Parent] Child completed successfully.\n");
        printf("[Parent] Shared memory result: %d\n",
               shared->processed);

        result = 0;
    }
    else
    {
        printf("[Parent] Child process failed.\n");
    }

cleanup:

    if (shared != MAP_FAILED)
        munmap(shared, sizeof(SharedData));

    if (shm_fd != -1)
        close(shm_fd);

    if (parent_sem != SEM_FAILED)
        sem_close(parent_sem);

    if (done_sem != SEM_FAILED)
        sem_close(done_sem);

    shm_unlink(SHM_NAME);
    sem_unlink(SEM_NAME);
    sem_unlink(DONE_NAME);

    if (result == 0)
        printf("[Parent] Shared memory and semaphores cleaned up.\n");

    return result;
}

