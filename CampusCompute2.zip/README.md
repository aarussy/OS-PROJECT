# CampusCompute

CampusCompute is a command-line Operating Systems mini-project written in C for
Linux/Ubuntu (or WSL Ubuntu). It demonstrates CPU scheduling, a threaded
producer-consumer logger, POSIX shared-memory IPC, the Banker's safety algorithm,
fork()/waitpid() worker management and setrlimit() resource limits.

## Prerequisites
- Ubuntu / WSL Ubuntu
- `gcc` and `make` (`sudo apt install build-essential`)
- POSIX threads, POSIX shared memory and named semaphores (standard on Linux)

## Build
```bash
make clean && make        # produces ./campuscompute
```
Compiles with `-Wall -Wextra -std=c11` and no warnings.

## Run
```bash
./campuscompute help                 # list commands
./campuscompute schedule fcfs        # FCFS (interactive input)
./campuscompute schedule rr          # Round Robin (asks for time quantum)
./campuscompute schedule priority    # non-preemptive Priority
./campuscompute compare              # all three on one job set + summary table
./campuscompute logger               # producer-consumer logger -> logs/campus.log
./campuscompute ipc                  # shared memory + named semaphores
./campuscompute banker safe          # predefined safe state
./campuscompute banker unsafe        # predefined unsafe state
./campuscompute banker custom        # user-entered state
./campuscompute worker normal        # child exits normally (status 0)
./campuscompute worker fail          # SIMULATED failure (intentional exit code 42)
./campuscompute limit                # RLIMIT_CPU demonstration
./campuscompute demo                 # integrated, non-interactive demo + summary
./campuscompute cleanup              # remove CampusCompute shm/semaphores
```
`make demo` is a shortcut for `./campuscompute demo`.

### Repeatable test inputs
Scheduling commands read from stdin, so fixed inputs can be piped in
(job count, then arrival / burst / priority for each job; Round Robin and
compare then read the time quantum):
```bash
./campuscompute schedule fcfs     < tests/jobs_sample.txt
./campuscompute schedule priority < tests/jobs_sample.txt
cat tests/jobs_sample.txt tests/rr_quantum.txt | ./campuscompute schedule rr
cat tests/jobs_sample.txt tests/rr_quantum.txt | ./campuscompute compare
./campuscompute schedule priority < tests/jobs_idle_gap_tie.txt   # idle gap + priority tie
```

## Scheduling rules
- FCFS: ordered by arrival time, ties broken by lower Job ID.
- Round Robin: FIFO ready queue, user-defined time quantum; jobs arriving during a
  time slice are queued before the preempted job is re-queued.
- Priority (non-preemptive): lower number = higher priority; ties broken by earlier
  arrival, then lower Job ID.
- CPU idle gaps are shown as `IDLE (start-end)` in the timeline.

## Features
- Threads: bounded queue (size 5), one mutex, two condition variables
  (`not_full`, `not_empty`); threads are joined and the log file is closed on exit.
- IPC: POSIX shared memory (`/campuscompute_shm`) plus two named semaphores
  (`/campuscompute_sem`, `/campuscompute_done`); all are unlinked when the run ends.
- Banker's algorithm: computes Need = Maximum - Allocation and prints a safe
  sequence or reports an unsafe state.
- Worker failure is **simulated** (the child deliberately calls `_exit(42)`); it is
  not a real OS failure. The parent detects it with `waitpid()` + `WEXITSTATUS`.
- Resource limit: child sets `RLIMIT_CPU` (soft 1 s, hard 2 s), spins on the CPU and
  receives `SIGXCPU`; its handler exits with code 24, which the parent reports.
- Cleanup: `./campuscompute cleanup` removes only the three IPC objects named above.

## Project structure
```text
include/campus.h
src/main.c  src/scheduler.c  src/logger.c  src/ipc.c
src/banker.c  src/worker.c  src/limits.c
tests/jobs_sample.txt  tests/jobs_idle_gap_tie.txt  tests/rr_quantum.txt
Makefile
README.md
logs/campus.log            (created at run time)
```

## Cleanup
```bash
./campuscompute cleanup    # program-created shared memory / semaphores
make clean                 # removes the executable (logs/ is kept)
```
