#ifndef CAMPUS_H
#define CAMPUS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/resource.h>
#include <fcntl.h>
#include <time.h>
#include <signal.h>

#define MAX_JOBS 20
#define MAX_RESOURCES 3
#define LOG_FILE "logs/campus.log"

int run_scheduler(int argc, char *argv[]);
int run_scheduler_sample(void);
int run_logger(void);
int run_ipc(void);
int run_banker(int argc, char *argv[]);
int run_worker(int argc, char *argv[]);
int run_limits(void);
int run_demo(void);
int run_cleanup(void);

void show_help(void);

#endif
